from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
import os
from pinecone import Pinecone, ServerlessSpec

# Initialize Pinecone (replace "your-api-key" with your actual API key)
pc = Pinecone(api_key="pcsk_6Ah8nH_JsPqoT59nZma6BnSXmintSQkLTC5b7nVbcEMhbrF3j5J79sxboS7Nh8uENX5GK8")

# Create a serverless index specification (replace region as needed)
serverless_spec = ServerlessSpec(cloud="aws", region="us-west-2")

# Extract Data From the PDF File
def load_pdf_file(data):
    loader = DirectoryLoader(data, glob="*.pdf", loader_cls=PyPDFLoader)
    documents = loader.load()
    return documents

# Split the Data into Text Chunks
def text_split(extracted_data):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
    text_chunks = text_splitter.split_documents(extracted_data)
    return text_chunks

# Download the Embeddings from HuggingFace
def download_hugging_face_embeddings():
    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
    return embeddings

# Create Pinecone index (replace "your-index-name" and dimension as needed)
def create_pinecone_index(index_name, dimension):
    if index_name not in pc.list_indexes().names:
        pc.create_index(
            name=index_name,
            dimension=dimension,
            metric="cosine",
            spec=serverless_spec
        )
    return pc.index(index_name)

# Store embeddings in Pinecone
def store_embeddings_in_pinecone(index, text_chunks, embeddings):
    for chunk in text_chunks:
        embedding = embeddings.embed_documents([chunk.page_content])[0]
        index.upsert([(chunk.metadata["id"], embedding)])

# Main function to load, split, and store embeddings
def main(data_directory, index_name="my_pinecone_index"):
    # Load and split the PDF data
    documents = load_pdf_file(data_directory)
    text_chunks = text_split(documents)
    
    # Download embeddings and create Pinecone index
    embeddings = download_hugging_face_embeddings()
    pinecone_index = create_pinecone_index(index_name, dimension=384)
    
    # Store embeddings in Pinecone
    store_embeddings_in_pinecone(pinecone_index, text_chunks, embeddings)
    print("Data stored in Pinecone successfully.")
