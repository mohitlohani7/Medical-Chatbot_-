document.getElementById('ask-button').addEventListener('click', function() {
    const userQuestion = document.getElementById('user-question').value;
    const systemPrompt = document.getElementById('system-prompt').value;
    const model = document.getElementById('model-select').value;
    const memoryLength = document.getElementById('memory-length').value;

    // Here you would send the userQuestion, systemPrompt, model, and memoryLength to your backend
    // Example (using fetch to send data to your backend):
    fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
 },
        body: JSON.stringify({
            userQuestion,
            systemPrompt,
            model,
            memoryLength,
        }),
    })
    .then(response => response.json())
    .then(data => {
        const chatHistory = document.getElementById('chat-history');
        const newMessage = document.createElement('div');
        newMessage.innerHTML = `<span class="user">${userQuestion}</span><br><span class="bot">${data.response}</span>`;
        chatHistory.appendChild(newMessage);
    })
    .catch(error => console.error('Error:', error));
});